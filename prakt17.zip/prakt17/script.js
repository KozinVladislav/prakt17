 $(document).ready(function(){
	$(".textInput").change(function(e){
		mail = $(this).val();
		$(".emailInput").val(mail);
	});
	
	$('.price').click(function(e) {
		$(".form").parent('.price').removeClass('active');
		$(this).addClass('active');
		console.log($(".form").parent('.price'));
		id = $(this).children('.form').attr('id');
		//console.log(id);
		$(".tarif").val(id);
	});

});
