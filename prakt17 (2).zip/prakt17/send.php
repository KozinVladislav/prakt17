<?php

header('Content-type: text/html; charset=utf-8');
$connect = new mysqli('localhost', 'root', '', 'prakt17');
if ($connect->connect_error) {
    die('Error : ('. $connect->connect_errno .') '. $connect->connect_error);
}
$connect->set_charset('utf8');		



if (isset($_POST['purchase'])) {
	if (!empty($_POST['email'])) {
		$row = $connect->query("SELECT * FROM `user` WHERE `email` = '" . $_POST['email']	. "' order by date; ");	
		$res = $row->fetch_all(MYSQLI_ASSOC);
		echo '<pre>';

		foreach ($res as $key => $value ) {
			foreach ($value as $k => $val) {
				echo "<br>$k: $val";	
			}	    	
	    }	
	} 
}

if (isset($_POST['submit'])) {
	$tarif = $_POST['tarif'];
	$date = date("d-m-Y H:i:s");
	$email = $_POST['email'];

	switch ($tarif) {
		case 'Basic':
			$cost = 19.99;
			break;	

		case 'QBasic':
			$cost = 29.99;
			break;
		
		case 'Turbo Basic':
			$cost = 39.99;
			break;
		
		case 'Visual Basic':
			$cost = 49.99;
			break;		
	}
	if (!empty($tarif)) {
	$connect->query("INSERT INTO `user` (`email`, `tarif`, `cost`, `date`) VALUES ('$email', '$tarif', '$cost', '$date'); ");
	header('Location: ' . 'index.html');
	} else die("Не выбран тариф!");
}


#4. К странице из 4й практической разработать скрипт, который после ввода почты, если был выбран тарифный план, то записывает #почту и выбранный тариф в БД, при нажатии кнопки purchase выводит все списком все тарифные планы выбранные, отсортированные по #дате заказа, для данной почты, и в конце общая сумма тарифов. Работу с БД реализовать с помощью функционального mySQLi.

